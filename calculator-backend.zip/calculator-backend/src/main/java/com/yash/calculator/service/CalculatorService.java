package com.yash.calculator.service;

import java.util.List;

import com.yash.calculator.model.Calculator;

public interface CalculatorService {
	public int evaluate(String expression);
	public boolean hasPrecedence(char op1, char op2);
	public int applyOp(char op, int b, int a);
	
	

}
