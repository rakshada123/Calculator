package com.yash.calculator.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.yash.calculator.model.Calculator;
import com.yash.calculator.repository.CalculatorDao;
import com.yash.calculator.service.CalculatorService;

@RestController
@CrossOrigin
@RequestMapping("/calculator")
public class CalculatorController {

	@Autowired
	public CalculatorDao calculatorDao;

	@Autowired
	public CalculatorService calculatorservice;

	public static int memory = 0;

	@PostMapping("/calculate")
	public String calculate(@RequestBody Calculator calculator) {
		System.out.println(calculatorservice.evaluate(calculator.getExpression()));
		return "" + calculatorservice.evaluate(calculator.getExpression());
	}

	@PostMapping("/addMemory")
	public String addMemory(@RequestBody Calculator calculator) {
		if (calculatorDao.findById(1).toString().equals("Optional.empty")) {
			calculatorDao.save(new Calculator(1, calculator.getMemory(), null));
		}

		calculator.setMemory(calculatorDao.findById(1).get().getMemory() + calculator.getMemory());
		calculatorDao.deleteById(1);
		calculatorDao.save(new Calculator(1, calculator.getMemory(), null));

		System.out.println("Memory saved after addition: " + calculatorDao.findById(1).get().getMemory());
		return "Memory saved after addition: " + calculatorDao.findById(1).get().getMemory();

	}

	@PostMapping("/substractMemory")
	public String substractMemory(@RequestBody Calculator calculator) {
		if (calculatorDao.findById(1).toString().equals("Optional.empty")) {
			calculatorDao.save(new Calculator(1, 0, null));
		}
		calculator.setMemory(calculatorDao.findById(1).get().getMemory() - calculator.getMemory());
		calculatorDao.deleteById(1);
		calculatorDao.save(new Calculator(1, calculator.getMemory(), null));

		System.out.println("Memory saved after substraction: " + calculatorDao.findById(1).get().getMemory());
		return "Memory saved after substraction: " + calculatorDao.findById(1).get().getMemory();
	}

	@GetMapping("/recallMemory")
	public String recallMemory() {
		if (calculatorDao.findById(1).toString().equals("Optional.empty")) {
			return ""+0;
		}
		System.out.println("Memory recall: " + calculatorDao.findById(1).get().getMemory());
		return "" + calculatorDao.findById(1).get().getMemory();

	}

}
