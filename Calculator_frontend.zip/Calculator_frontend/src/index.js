import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';

ReactDOM.render(<App />, document.getElementById('root'));



// fetch("http://localhost:8080/customer/customer_exist", {            
// 					method: "POST",            
// 					headers: { "Content-Type": "application/json" },            
// 					body: JSON.stringify(customeremail)        
// 				})